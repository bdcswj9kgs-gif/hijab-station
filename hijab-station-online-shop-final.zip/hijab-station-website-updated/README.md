# হিজাব স্টেশন — Online Shop

এই ভার্সনে যোগ করা হয়েছে:
- Premium home/brand design
- ৩টি product catalog: Arabian Silk ৳250, Chiffon Georgette ৳200, Popcorn Cotton ৳200
- Search + category filter
- Add to Cart + quantity control + remove item
- Cart data saved in browser (localStorage)
- Checkout form: name, phone, address, delivery area, payment method, note
- Delivery calculation: Dhaka ৳60 / outside Dhaka ৳120 (script.js থেকে পরিবর্তনযোগ্য)
- Cash on Delivery / bKash / Nagad option
- Order message generator for WhatsApp / Messenger
- Responsive mobile design

## GitHub Pages
`index.html`, `style.css`, `script.js` এবং ৩টি PNG একই folder-এ রাখুন।

## গুরুত্বপূর্ণ: আপনার business links বসান
`script.js`-এর `SHOP_CONFIG` অংশে:
- `whatsappNumber`: 8801XXXXXXXXX-এর জায়গায় আপনার WhatsApp নম্বর দিন
- `messengerUrl`: আপনার Facebook Page/Messenger URL দিন

তারপর GitHub repository-তে সব ফাইল upload/replace করুন।
