/* Hijab Station — simple front-end shop. Update these two links with your real business accounts. */
const SHOP_CONFIG={
  whatsappNumber:"8801XXXXXXXXX", // Example: 88017XXXXXXXX — replace with your WhatsApp number
  messengerUrl:"#",              // Replace with your Facebook Page/Messenger URL
  delivery:{dhaka:60,outside:120}
};

const products=[
  {id:"arabian-silk",name:"এরাবিয়ান সিল্ক হিজাব",category:"silk",categoryBn:"এরাবিয়ান সিল্ক",price:250,tag:"PREMIUM",meta:"Silky • Elegant",desc:"নরম • মসৃণ • প্রিমিয়াম কোয়ালিটি",image:"a_clean_glossy_product_catalog_poster_image_in.png",colors:"২৪+ কালার"},
  {id:"chiffon-georgette",name:"শিফন জর্জেট হিজাব",category:"chiffon",categoryBn:"শিফন জর্জেট",price:200,tag:"BEST SELLER",meta:"Light • Soft",desc:"হালকা • নরম • আরামদায়ক • প্রতিদিনের জন্য",image:"a_clean_pastel_elegant_product_advertisement_pos.png",colors:"৩০+ কালার"},
  {id:"popcorn-cotton",name:"পপকর্ন কটন হিজাব",category:"cotton",categoryBn:"পপকর্ন কটন",price:200,tag:"OFFER",meta:"Textured • Comfortable",desc:"নরম • হালকা • আরামদায়ক • ট্রেন্ডি কালার",image:"a_clean_colorful_product_catalog_poster_social.png",colors:"১৮+ কালার"}
];

let cart=JSON.parse(localStorage.getItem("hijabStationCart")||"[]");
let activeFilter="all";

const $=s=>document.querySelector(s);
const money=n=>`৳ ${Number(n).toLocaleString("bn-BD")}`;
const getProduct=id=>products.find(p=>p.id===id);

function saveCart(){localStorage.setItem("hijabStationCart",JSON.stringify(cart));}
function cartQty(){return cart.reduce((sum,i)=>sum+i.qty,0)}
function subtotal(){return cart.reduce((sum,i)=>sum+(getProduct(i.id)?.price||0)*i.qty,0)}
function delivery(){return cart.length?(document.querySelector("#deliveryArea")?.value==="outside"?SHOP_CONFIG.delivery.outside:SHOP_CONFIG.delivery.dhaka):0}

function renderProducts(){
  const q=$("#searchInput").value.trim().toLowerCase();
  const list=products.filter(p=>{
    const matchesFilter=activeFilter==="all"||p.category===activeFilter;
    const text=(p.name+p.categoryBn+p.desc).toLowerCase();
    return matchesFilter&&(!q||text.includes(q));
  });
  $("#productGrid").innerHTML=list.map(p=>`<article class="product-card">
    <div class="product-image-wrap"><span class="badge ${p.tag==='OFFER'?'offer':''}">${p.tag}</span><img loading="lazy" src="${p.image}" alt="${p.name}"></div>
    <div class="card-body"><div class="product-meta"><span>${p.meta} • ${p.colors}</span><b>${money(p.price)}</b></div><h3>${p.name}</h3><p>${p.desc}</p>
      <div class="product-actions"><button class="add-btn" data-add="${p.id}" type="button">+ কার্টে যোগ করুন</button><button class="details-btn" data-detail="${p.id}" type="button">বিস্তারিত</button></div>
    </div></article>`).join("");
  $("#emptyState").hidden=list.length>0;
}

function renderCart(){
  $("#cartCount").textContent=cartQty().toLocaleString("bn-BD");
  if(!cart.length){
    $("#cartItems").innerHTML=`<div class="cart-empty"><div style="font-size:42px">🛍️</div><h3>আপনার কার্ট খালি</h3><p>পছন্দের হিজাবগুলো কার্টে যোগ করুন।</p><a class="btn primary" href="#products" id="goShop">শপে যান</a></div>`;
    $("#cartBottom").style.display="none";
  }else{
    $("#cartItems").innerHTML=cart.map(i=>{const p=getProduct(i.id);return `<div class="cart-item"><img src="${p.image}" alt="${p.name}"><div><h4>${p.name}</h4><p>${money(p.price)} × ${i.qty} = <b>${money(p.price*i.qty)}</b></p><div class="qty"><button data-dec="${p.id}" type="button">−</button><span>${i.qty}</span><button data-inc="${p.id}" type="button">+</button></div></div><button class="remove" data-remove="${p.id}" type="button" aria-label="Remove">×</button></div>`}).join("");
    $("#cartBottom").style.display="block";
  }
  updateTotals();
}

function updateTotals(){
  const sub=subtotal(), del=delivery(), total=sub+del;
  $("#cartSubtotal").textContent=money(sub);$("#cartDelivery").textContent=money(del);$("#cartTotal").textContent=money(total);
  $("#checkoutSubtotal").textContent=money(sub);$("#checkoutDelivery").textContent=money(del);$("#checkoutTotal").textContent=money(total);
}

function addToCart(id){
  const found=cart.find(i=>i.id===id); if(found)found.qty++; else cart.push({id,qty:1});
  saveCart();renderCart();openCart();
}
function changeQty(id,d){const i=cart.find(x=>x.id===id);if(!i)return;i.qty+=d;if(i.qty<=0)cart=cart.filter(x=>x.id!==id);saveCart();renderCart()}

function openCart(){$("#cartDrawer").classList.add("open");$("#overlay").classList.add("show");document.body.classList.add("no-scroll")}
function closeCart(){$("#cartDrawer").classList.remove("open");$("#overlay").classList.remove("show");document.body.classList.remove("no-scroll")}
function openCheckout(){if(!cart.length){openCart();return}closeCart();$("#checkoutModal").classList.add("show");document.body.classList.add("no-scroll");updateTotals()}
function closeCheckout(){$("#checkoutModal").classList.remove("show");document.body.classList.remove("no-scroll")}

function orderText(data){
  const lines=cart.map(i=>{const p=getProduct(i.id);return `• ${p.name} — ${i.qty}টি × ${p.price} = ${p.price*i.qty}৳`}).join("\n");
  const del=data.area==="outside"?SHOP_CONFIG.delivery.outside:SHOP_CONFIG.delivery.dhaka;
  return `আসসালামু আলাইকুম 🌸\nহিজাব স্টেশনে অর্ডার করতে চাই।\n\nনাম: ${data.name}\nমোবাইল: ${data.phone}\nঠিকানা: ${data.address}\nডেলিভারি: ${data.area==="outside"?"ঢাকার বাইরে":"ঢাকার ভিতরে"}\nপেমেন্ট: ${data.payment}\n\nপণ্য:\n${lines}\n\nপণ্যের মূল্য: ${subtotal()}৳\nডেলিভারি: ${del}৳\nসর্বমোট: ${subtotal()+del}৳\n\nনোট: ${data.note||"নেই"}`;
}

function setupLinks(){if(SHOP_CONFIG.messengerUrl&&SHOP_CONFIG.messengerUrl!=="#")$("#messengerLink").href=SHOP_CONFIG.messengerUrl;else $("#messengerLink").href="#";}

$(document).addEventListener("click",e=>{
  const add=e.target.closest("[data-add]");if(add){addToCart(add.dataset.add);return}
  const inc=e.target.closest("[data-inc]");if(inc){changeQty(inc.dataset.inc,1);return}
  const dec=e.target.closest("[data-dec]");if(dec){changeQty(dec.dataset.dec,-1);return}
  const rem=e.target.closest("[data-remove]");if(rem){cart=cart.filter(i=>i.id!==rem.dataset.remove);saveCart();renderCart();return}
  const detail=e.target.closest("[data-detail]");if(detail){const p=getProduct(detail.dataset.detail);alert(`${p.name}\n\n${p.desc}\n\nমূল্য: ${money(p.price)}\n\nএই পণ্যটি কার্টে যোগ করতে “+ কার্টে যোগ করুন” চাপুন।`);return}
  const pill=e.target.closest("[data-filter]");if(pill){activeFilter=pill.dataset.filter;document.querySelectorAll("[data-filter]").forEach(b=>b.classList.toggle("active",b.dataset.filter===activeFilter));$("#categoryFilter").value=activeFilter;renderProducts();return}
  if(e.target.id==="goShop")closeCart();
});

$("#openCart").addEventListener("click",openCart);$("#heroCart").addEventListener("click",openCart);$("#contactCart").addEventListener("click",openCart);$("#closeCart").addEventListener("click",closeCart);$("#overlay").addEventListener("click",closeCart);$("#checkoutBtn").addEventListener("click",openCheckout);$("#closeCheckout").addEventListener("click",closeCheckout);$("#searchInput").addEventListener("input",renderProducts);
$("#categoryFilter").addEventListener("change",e=>{activeFilter=e.target.value;document.querySelectorAll("[data-filter]").forEach(b=>b.classList.toggle("active",b.dataset.filter===activeFilter));renderProducts()});
$("#deliveryArea").addEventListener("change",updateTotals);

$("#orderForm").addEventListener("submit",e=>{
  e.preventDefault();
  const data=Object.fromEntries(new FormData(e.target).entries());
  const text=orderText(data);
  const wa=SHOP_CONFIG.whatsappNumber.replace(/\D/g,"");
  $("#sendWhatsApp").href=wa&&wa!=="8801XXXXXXXXX"?`https://wa.me/${wa}?text=${encodeURIComponent(text)}`:`https://wa.me/?text=${encodeURIComponent(text)}`;
  $("#sendMessenger").href=SHOP_CONFIG.messengerUrl&&SHOP_CONFIG.messengerUrl!=="#"?SHOP_CONFIG.messengerUrl:"#";
  $("#successText").textContent=`${data.name}, আপনার ${cartQty().toLocaleString("bn-BD")}টি পণ্যের অর্ডার তথ্য প্রস্তুত হয়েছে। এখন WhatsApp বা Messenger-এ পাঠিয়ে কনফার্ম করুন।`;
  $("#checkoutModal").classList.remove("show");$("#successModal").classList.add("show");
  localStorage.setItem("hijabStationLastOrder",JSON.stringify({data,text,createdAt:new Date().toISOString()}));
  cart=[];saveCart();renderCart();
});

$("#closeSuccess").addEventListener("click",()=>{$("#successModal").classList.remove("show");document.body.classList.remove("no-scroll")});
$("#sendWhatsApp").addEventListener("click",()=>{$("#successModal").classList.remove("show");document.body.classList.remove("no-scroll")});

renderProducts();renderCart();setupLinks();
