# হিজাব স্টেশন — Updated Product Website

এই ভার্সনে ৩টি নতুন/বাস্তব পণ্য যোগ করা হয়েছে:

1. এরাবিয়ান সিল্ক হিজাব — ৳250
2. শিফন জর্জেট হিজাব — ৳200
3. পপকর্ন কটন হিজাব — ৳200 (Offer)

প্রতিটি পণ্যের জন্য আগের তৈরি catalog image ব্যবহার করা হয়েছে।

## GitHub Pages-এ আপডেট

`index.html`, `style.css` এবং ৩টি PNG image একই repository folder-এ upload/replace করুন।

যে image file-গুলো রাখতে হবে:
- a_clean_glossy_product_catalog_poster_image_in.png
- a_clean_pastel_elegant_product_advertisement_pos.png
- a_clean_colorful_product_catalog_poster_social.png

Facebook Page-এর আসল link বসাতে `index.html`-এর `href="#"` placeholder পরিবর্তন করুন।
